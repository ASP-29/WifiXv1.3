#include <ESP8266WiFi.h>

// include ESP8266 Non-OS SDK functions
extern "C" {
#include "user_interface.h"
}
#define CHANNEL_HOP_INTERVAL_MS   1000
static os_timer_t channelHop_timer;
// ===== SETTINGS ===== //
#define TYPE_MANAGEMENT       0x00
#define TYPE_CONTROL          0x01
#define TYPE_DATA             0x02
#define SUBTYPE_PROBE_REQUEST 0x04
//#define LED 2              /* LED pin (2=built-in LED) */
#define LED_INVERT true    /* Invert HIGH/LOW for LED */
#define SERIAL_BAUD 115200 /* Baudrate for serial communication */
#define CH_TIME 140        /* Scan time (in ms) per channel */
#define PKT_RATE 5         /* Min. packets before it gets recognized as an attack */
#define PKT_TIME 1         /* Min. interval (CH_TIME*CH_RANGE) before it gets recognized as an attack */
#define DATA_LENGTH           112
// Channels to scan on (US=1-11, EU=1-13, JAP=1-14)
//const short channels[] = { 1,2,3,4,5,6,7,8,9,10,11,12,13/*,14*/ };

// ===== Runtime variables ===== //
int ch_index { 0 };               // Current index of channel array
int packet_rate { 0 };            // Deauth packet counter (resets with each update)
int attack_counter { 0 };         // Attack counter
unsigned long update_time { 0 };  // Last update time
unsigned long ch_time { 0 };      // Last channel hop time
static void getMAC(char *addr, uint8_t* data, uint16_t offset) {
  sprintf(addr, "%02x:%02x:%02x:%02x:%02x:%02x", data[offset+0], data[offset+1], data[offset+2], data[offset+3], data[offset+4], data[offset+5]);
}



static void printDataSpan(uint16_t start, uint16_t size, uint8_t* data) {
  for(uint16_t i = start; i < DATA_LENGTH && i < start+size; i++) {
    Serial.write(data[i]);
  }
}
// ===== Sniffer function ===== //

struct RxControl {
 signed rssi:8; // signal intensity of packet
 unsigned rate:4;
 unsigned is_group:1;
 unsigned:1;
 unsigned sig_mode:2; // 0:is 11n packet; 1:is not 11n packet;
 unsigned legacy_length:12; // if not 11n packet, shows length of packet.
 unsigned damatch0:1;
 unsigned damatch1:1;
 unsigned bssidmatch0:1;
 unsigned bssidmatch1:1;
 unsigned MCS:7; // if is 11n packet, shows the modulation and code used (range from 0 to 76)
 unsigned CWB:1; // if is 11n packet, shows if is HT40 packet or not
 unsigned HT_length:16;// if is 11n packet, shows length of packet.
 unsigned Smoothing:1;
 unsigned Not_Sounding:1;
 unsigned:1;
 unsigned Aggregation:1;
 unsigned STBC:2;
 unsigned FEC_CODING:1; // if is 11n packet, shows if is LDPC packet or not.
 unsigned SGI:1;
 unsigned rxend_state:8;
 unsigned ampdu_cnt:8;
 unsigned channel:4; //which channel this packet in.
 unsigned:12;
};

struct SnifferPacket{
    struct RxControl rx_ctrl;
    uint8_t data[DATA_LENGTH];
    uint16_t cnt;
    uint16_t len;
};
 static void showMetadata(SnifferPacket *snifferPacket);
static void ICACHE_FLASH_ATTR sniffer_callback(uint8_t *buffer, uint16_t length);
//static void printDataSpan(uint16_t start, uint16_t size, uint8_t* data);


void channelHop()
{
  // hoping channels 1-13
  uint8 new_channel = wifi_get_channel() + 1;
  if (new_channel > 13) {
    new_channel = 1;
  }
  wifi_set_channel(new_channel);
}

void sniffer(uint8_t *buf, uint16_t len) {
  String probeSSID;
  //pinMode(2,OUTPUT);
  SnifferPacket *snifferPacket;
  if (!buf || len < 28) return; // Drop packets without MAC header
  char addr[] = "00:00:00:00:00:00";
  char addr2[] = "00:00:00:00:00:00";
  byte pkt_type = buf[12]; // second half of frame control field
  byte* addr_a = &buf[16]; // first MAC address
  byte* addr_b = &buf[22]; // second MAC address
  getMAC(addr,addr_a,0);
  getMAC(addr2,addr_b,0);
  
  
 
  
 //Serial.println(addr_b);
  // If captured packet is a deauthentication or dissassociaten frame
  if (pkt_type == 0xA0 || pkt_type == 0xC0) {
    ++packet_rate;
    Serial.print("First MAC: ");
  Serial.print(addr);
  Serial.print(", Seconds MAC: ");
  Serial.print(addr2);
  Serial.print(", Packet: ");
  Serial.print(packet_rate);
  Serial.print(", RSSI: ");
  struct RxControl *sniffer = (struct RxControl*) buf;
  Serial.println(sniffer->rssi);
  //digitalWrite(2,LOW);
  delay(100);
  } 
  else {
    //digitalWrite(2,HIGH);
    //packet_rate =0;
  }
 // if ((buf[12] == 0x40) && (buf[37] > 0)) {
 //   Serial.print("probe req"); 
  
 // }
}
static void showMetadata(SnifferPacket *snifferPacket) {

  unsigned int frameControl = ((unsigned int)snifferPacket->data[1] << 8) + snifferPacket->data[0];
  //pinMode(2,OUTPUT);
  uint8_t version      = (frameControl & 0b0000000000000011) >> 0;
  uint8_t frameType    = (frameControl & 0b0000000000001100) >> 2;
  uint8_t frameSubType = (frameControl & 0b0000000011110000) >> 4;
  uint8_t toDS         = (frameControl & 0b0000000100000000) >> 8;
  uint8_t fromDS       = (frameControl & 0b0000001000000000) >> 9;
  //digitalWrite(2,HIGH);
  // Only look for probe request packets
  if (frameType != TYPE_MANAGEMENT ||
      frameSubType != SUBTYPE_PROBE_REQUEST)
        return;
  delay(100);
  //digitalWrite(2,LOW);
  Serial.print("RSSI: ");
  Serial.print(snifferPacket->rx_ctrl.rssi, DEC);

  Serial.print(" Ch: ");
  Serial.print(wifi_get_channel());

  char addr[] = "00:00:00:00:00:00";
  getMAC(addr, snifferPacket->data, 10);
  Serial.print(" Peer MAC: ");
  Serial.print(addr);
  
  uint8_t SSID_length = snifferPacket->data[25];
  Serial.print(" SSID: ");
  printDataSpan(26, SSID_length, snifferPacket->data);
  
  Serial.println();
}
static void ICACHE_FLASH_ATTR sniffer_callback(uint8_t *buffer, uint16_t length) {
  struct SnifferPacket *snifferPacket = (struct SnifferPacket*) buffer;
  showMetadata(snifferPacket);
}

/**
 * Callback for promiscuous mode
 */



// ===== Attack detection functions ===== //
void attack_started() {
  //digitalWrite(LED, !LED_INVERT); // turn LED on
  Serial.println("ATTACK DETECTED");
}

void attack_stopped() {
  //digitalWrite(LED, LED_INVERT); // turn LED off
  Serial.println("ATTACK STOPPED");
}
void setup_d_detector(){
   WiFi.disconnect();                   // Disconnect from any saved or active WiFi connections
  wifi_set_opmode(STATION_MODE);       // Set device to client/station mode
  wifi_set_promiscuous_rx_cb(sniffer); // Set sniffer function
  wifi_set_channel(1);        // Set channel
  wifi_promiscuous_enable(true);       // Enable sniffer
  os_timer_disarm(&channelHop_timer);
  os_timer_setfn(&channelHop_timer, (os_timer_func_t *) channelHop, NULL);
  os_timer_arm(&channelHop_timer, CHANNEL_HOP_INTERVAL_MS, 1);

  Serial.println("Started \\o/");
}
void setupprobe(){
  WiFi.disconnect(); 
  WiFi.mode(WIFI_OFF);
  delay(20);
  wifi_set_opmode(STATION_MODE);
  wifi_set_promiscuous_rx_cb(sniffer_callback);
  //wifi_set_channel(1);
  wifi_promiscuous_enable(true);
  os_timer_disarm(&channelHop_timer);
  os_timer_setfn(&channelHop_timer, (os_timer_func_t *) channelHop, NULL);
  os_timer_arm(&channelHop_timer, CHANNEL_HOP_INTERVAL_MS, 1);

}
